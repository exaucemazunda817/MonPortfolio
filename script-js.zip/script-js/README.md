# SCRIPT.JS

A Pen created on CodePen.

Original URL: [https://codepen.io/Exauc-Mazunda/pen/RNWdKYd](https://codepen.io/Exauc-Mazunda/pen/RNWdKYd).

