// Menu mobile simple
document.getElementById("openMenu")?.addEventListener("click", function(){
  alert("Menu mobile : cliquez sur les liens en haut pour naviguer.");
});

// Validation formulaire
document.getElementById("contactForm")?.addEventListener("submit", function(e){
  e.preventDefault();
  let nom = document.getElementById("nom").value.trim();
  let email = document.getElementById("email").value.trim();
  let message = document.getElementById("message").value.trim();

  if(!nom || !email || !message){
    alert("Veuillez remplir tous les champs !");
    return;
  }

  let re = /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/;
  if(!re.test(email)){
    alert("Adresse email invalide !");
    return;
  }

  alert("Merci " + nom + ", ton message a bien été envoyé !");
  this.reset();
});